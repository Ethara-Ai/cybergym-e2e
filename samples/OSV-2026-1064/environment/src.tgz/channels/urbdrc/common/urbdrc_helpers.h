/**
 * FreeRDP: A Remote Desktop Protocol Implementation
 * Server USB redirection channel - helper functions
 *
 * Copyright 2019 Armin Novak <armin.novak@thincast.com>
 * Copyright 2019 Thincast Technologies GmbH
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *	 http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef FREERDP_CHANNEL_URBDRC_HELPERS_H
#define FREERDP_CHANNEL_URBDRC_HELPERS_H

#include <winpr/wtypes.h>

#ifdef __cplusplus
extern "C"
{
#endif

#include <winpr/wlog.h>
#include <winpr/stream.h>
#include <freerdp/api.h>

	WINPR_ATTR_NODISCARD FREERDP_LOCAL const char* urb_function_string(UINT16 urb);

	WINPR_ATTR_NODISCARD FREERDP_LOCAL const char* mask_to_string(UINT32 mask);

	WINPR_ATTR_NODISCARD FREERDP_LOCAL const char* interface_to_string(UINT32 id);

	WINPR_ATTR_NODISCARD FREERDP_LOCAL const char* call_to_string(BOOL client, UINT32 interfaceNr,
	                                                              UINT32 functionId);

	FREERDP_LOCAL
	void urbdrc_dump_message(wLog* log, BOOL client, BOOL write, wStream* s);

	WINPR_ATTR_MALLOC(Stream_Free, 1)
	WINPR_ATTR_NODISCARD FREERDP_LOCAL wStream*
	create_shared_message_header_with_functionid(UINT32 InterfaceId, UINT32 MessageId,
	                                             UINT32 FunctionId, size_t OutputSize);

	WINPR_ATTR_NODISCARD FREERDP_LOCAL BOOL write_shared_message_header_with_functionid(
	    wStream* s, UINT32 InterfaceId, UINT32 MessageId, UINT32 FunctionId);

#ifdef __cplusplus
}
#endif

#endif /* FREERDP_CHANNEL_URBDRC_HELPERS_H */
